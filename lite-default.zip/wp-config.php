<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db_name' );

include_once('/home/cgssitec/public_html/subdomain_create/include-databaseauth.php');

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'a+@Y~c*ek6{A5&_l@#W7[Dd]C-8U-3dlcM|lhw6oYeF[8A%?^6)_8(x^uYEzwG94');
define('SECURE_AUTH_KEY',  'h3tq0<[_,]s+l#C(OLzG?D,,dvm*OD+TbC*Dza!T Z[}l-6N@(`dqh|8/>G+jahg');
define('LOGGED_IN_KEY',    'cX/K.cmCc}HgD-/gv&ojwM#m7N$j{fyFXBNdSS}c=6,ZI46k+[6m:i{2o&e:vRoF');
define('NONCE_KEY',        'i9+9OT^x&$n&GAG+Q%6Q|4(h44[U|aD6h14[w*&8KC?,|]$|(B]CG3Ixcqq0aW2~');
define('AUTH_SALT',        'Mpyq+66sa^NU~wT-r27|r5_A+,.^oi+y7]*DCyy+%wt(SU@zTMo:vmk+&+bsv+Ed');
define('SECURE_AUTH_SALT', 'IVNHZx2h__p2!A5lJ^W;-A-Lq?s>X}%75t&=VF~@w!Pxluxxoy,+g2&Fy5-,Q|Z*');
define('LOGGED_IN_SALT',   '%.T`s<QYB>n]a_b&,yKrNzLs|-/?pj-~ D9De]o^VbaJQ!ALHQ).zJDs|wmzw7X}');
define('NONCE_SALT',       'kP/.x+x|K=;b|8*BOi+iIr]jsvYM~$L(|aa.(>d$$B Ul+=DvoaRG&h~+T|VldvQ');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
