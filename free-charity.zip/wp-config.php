<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db_name' );

include_once('/home/cgssitec/public_html/subdomain_create/include-databaseauth.php');

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '7f%QhRbNezS*J(iWM<S*XC,N0;im2_Hx[vChV<PR/HOvK3^fYbRQ9,-o?=STQ?(.');
define('SECURE_AUTH_KEY',  'fa}%%+PMJACb]T3-+{|/ucnC8u`>AWD@jg`*Ry}ueQ`X:@OlxoFC+_uwKZj  4@_');
define('LOGGED_IN_KEY',    '!BOY=cGT>2M:2h8I!4Q,-ZqLQQXn#+rqR_sUMq+C|4G~<[KB0bkwktItCA%!+,vd');
define('NONCE_KEY',        'W-G,E=L8pR:3B{HuE|mf1A]=)eV2o[v^a%0N2%=-f-OS:s>2T0LS$lOjVK*H7kU{');
define('AUTH_SALT',        'Q5yXN%F%kv9u>tVrbfaUIUVJs=`_`YuD+MV+F<)wYdm+uK<ni.*yZ7?vgt|LD|0@');
define('SECURE_AUTH_SALT', '(lu_D/JZ)4H@S+]Tb:%9L@_ixr%H#M4k?9d9r?<aoVZ^zSIA77$au/LIKt5I>^|-');
define('LOGGED_IN_SALT',   '$k<m,-8R}|Z9]R%5$:UaIDCj6.-wN8#-@1 [|b4Q--2wD}RPv.Qw#m)~VpV@MSOL');
define('NONCE_SALT',       '.SM3gLGNC+TJv2A%[-TM}gX]1#yV),m:zHSw- T{0e6+oB:tn7^Y:9S/HJNeAW;2');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
