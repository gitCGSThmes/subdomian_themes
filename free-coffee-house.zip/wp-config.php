<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db_name' );

include_once('/home/cgssitec/public_html/subdomain_create/include-databaseauth.php');

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y05-|Q;GwW9]A/G8lpQYP3dGfQ)8-o/z{wcsmgHldHE/gTVJA 1(-EcVwz[M4[-p');
define('SECURE_AUTH_KEY',  'X?(}c/W#B>_dB)rgatK91Kd+S=1mFGBkKjUWM6mIj(|yQy@dGHdT^*}ne&M1>-A*');
define('LOGGED_IN_KEY',    '5L/]$~-0_. A$P/J4+sRz]/%r0RK45>cr]43_o9BiFnV*etZ3Wt)A5|(#}+i>5@M');
define('NONCE_KEY',        'mEYgVQH-x$Y9sSz{ifp9zTQW[%mQ&6]JZy%B!bJ.1t{HoIq?c.]u+s1=qIh3917v');
define('AUTH_SALT',        'MqH+@]RuRc_in/7e&w9/[Z^c%j0-]H:}Y| neNE?uLQfLm$f;Nd`C0CywfyD(xTw');
define('SECURE_AUTH_SALT', 'c%L};3-K(.D.( YxkQ%*Sn7ZipozZjETvO$}ot@3e>f@1OG@0$8dy OcT@*0:[f!');
define('LOGGED_IN_SALT',   'x7#jM_0t /nKBh_r!-mgz|QlXC++U|)6rdv[d`!)k`ytE~kD0QC@N|T_xkN.[Dl=');
define('NONCE_SALT',       '{oWhKO/6E-]+^h*4h~yd;zj=/l9Si>j;Z=oYuydET(EbT(Lxz)2*IVF#Ww1NhRH|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
